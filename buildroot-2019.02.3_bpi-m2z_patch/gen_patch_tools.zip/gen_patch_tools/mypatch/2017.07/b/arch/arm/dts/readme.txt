v1:

Error: <stdin>:123.1-6 Label or path cpu0 not found
Error: <stdin>:128.1-7 Label or path ehci0 not found
Error: <stdin>:133.1-4 Label or path de not found
Error: <stdin>:137.1-6 Label or path hdmi not found
Error: <stdin>:141.1-10 Label or path hdmi_out not found
Error: <stdin>:147.1-12 Label or path sound_hdmi not found
Error: <stdin>:151.1-6 Label or path i2s2 not found
Error: <stdin>:155.1-8 Label or path mixer0 not found
Error: <stdin>:191.1-7 Label or path ohci0 not found
Error: <stdin>:195.1-7 Label or path tcon0 not found
Error: <stdin>:211.1-9 Label or path usb_otg not found


v2: 

arch/arm/dts/sun8i-h3-bananapi-m2-plus.dtb: ERROR (phandle_references): /soc/serial@01c28400: Reference to non-existent node or label "uart1_pins"

arch/arm/dts/sun8i-h3-bananapi-m2-plus.dtb: ERROR (phandle_references): /soc/serial@01c28400: Reference to non-existent node or label "uart1_rts_cts_pins"

arch/arm/dts/sun8i-h3-bananapi-m2-plus.dtb: ERROR (phandle_references): /connector/port/endpoint: Reference to non-existent node or label "hdmi_out_con"

ERROR: Input tree has errors, aborting (use -f to force output)


