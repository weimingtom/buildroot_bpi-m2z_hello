
cp -a apple.dat /usr/local/bin
cp -a bpi_test_* /usr/local/bin
