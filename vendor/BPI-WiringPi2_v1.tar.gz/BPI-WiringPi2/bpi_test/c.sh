
cp -a 52pi bpi_test_52pi
cp -a gpio40 bpi_test_gpio40
cp -a hello bpi_test_hello
cp -a lcd1602 bpi_test_lcd1602
